# OmnisFlow (Simulovaný EEG backend)

Tato verze backendu generuje simulovaný EEG signál pomocí knihovny NeuroKit2 a odesílá každou sekundu fokus (poměr beta/alpha) + doporučení uživateli.

## Spuštění

1. Nainstaluj závislosti:
    pip install -r requirements.txt

2. Spusť backend:
    uvicorn main:app --reload

3. WebSocket poběží na:
    ws://localhost:8000/ws
