from fastapi import FastAPI, WebSocket
import asyncio
import neurokit2 as nk
import numpy as np

app = FastAPI()

def simulate_focus():
    eeg = nk.eeg_simulate(duration=1, sampling_rate=250, noise=0.2)
    psd = nk.signal_power(eeg, sampling_rate=250, method='welch', show=False)
    alpha = psd["Alpha"]
    beta = psd["Beta"]
    focus = beta / (alpha + 1e-6)
    return float(np.clip(focus, 0, 5))

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    while True:
        focus = simulate_focus()
        prompt = "Odeslat." if focus > 1.5 else "Impuls? Zvaž to."
        await ws.send_json({"focus": focus, "prompt": prompt})
        await asyncio.sleep(1)
