// Tento soubor obsahuje 3 doplňující komponenty pro OmnisFlow:
// 1. Mentální počasí
// 2. Thought DNA – mentální podpis
// 3. Omnis Echo – AI reflexe

import React, { useState, useEffect } from 'react';

// 1. Mentální počasí (jednoduchá analýza podle posledních focus hodnot)
export function MentalWeather({ data }) {
  const [weather, setWeather] = useState("--");

  useEffect(() => {
    if (data.length < 5) return;
    const avg = data.slice(-5).reduce((acc, d) => acc + d.focus, 0) / 5;
    if (avg > 3.5) setWeather("🌞 Jasná mysl");
    else if (avg > 2) setWeather("⛅ Mírné turbulence");
    else setWeather("🌧 Mentální přeháňky");
  }, [data]);

  return <div className="text-xl mt-4">Mentální počasí: {weather}</div>;
}

// 2. Thought DNA (generuje podpis myšlení)
export function ThoughtDNA({ data }) {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    if (data.length < 30) return;
    const focusValues = data.map(d => d.focus);
    const avg = focusValues.reduce((a, b) => a + b, 0) / focusValues.length;
    const variance = focusValues.reduce((sum, f) => sum + Math.pow(f - avg, 2), 0) / focusValues.length;
    const volatility = Math.sqrt(variance);

    setProfile({
      average: avg.toFixed(2),
      volatility: volatility.toFixed(2),
      stability: volatility < 0.8 ? "Vyrovnaný" : volatility > 1.5 ? "Výbušný" : "Proměnlivý"
    });
  }, [data]);

  if (!profile) return null;
  return (
    <div className="mt-6">
      <h3 className="text-md">🧬 Mentální podpis (Thought DNA)</h3>
      <p>Průměrné soustředění: {profile.average}</p>
      <p>Kolísání: {profile.volatility}</p>
      <p>Typ mysli: <strong>{profile.stability}</strong></p>
    </div>
  );
}

// 3. Omnis Echo – AI reflexní odpověď (jednoduchý rule-based reflexní systém)
export function OmnisEcho({ data }) {
  const [message, setMessage] = useState(null);

  useEffect(() => {
    if (data.length < 10) return;
    const recent = data.slice(-10);
    const avg = recent.reduce((acc, d) => acc + d.focus, 0) / 10;

    if (avg < 1.5) setMessage("🌀 Tvá mysl je rozptýlená. Co tě právě odvádí od středu?");
    else if (avg > 3.5) setMessage("🎯 Tvá mysl je vysoce zaměřená. Jsi v zóně. Nechci rušit.");
    else if (recent[9].focus - recent[0].focus > 1.5) setMessage("📈 Prudký nárůst pozornosti. Co tě právě inspirovalo?");
    else if (recent[0].focus - recent[9].focus > 1.5) setMessage("📉 Pokles soustředění. Cítíš únavu, nebo ztrácíš směr?");
    else setMessage(null);
  }, [data]);

  return message ? <div className="mt-6 italic">Omnis Echo říká: "{message}"</div> : null;
}
