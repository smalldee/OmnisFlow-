import React, { useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';

const Starfield = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let stars = [];
    const numStars = 200;
    const speed = 0.05;

    const initStars = () => {
      stars = Array.from({ length: numStars }).map(() => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        z: Math.random() * canvas.width
      }));
    };

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initStars();
    };

    const animate = () => {
      ctx.fillStyle = 'black';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      stars.forEach(star => {
        star.z -= speed;
        if (star.z <= 0) star.z = canvas.width;

        const k = 128.0 / star.z;
        const x = star.x - canvas.width / 2;
        const y = star.y - canvas.height / 2;
        const px = x * k + canvas.width / 2;
        const py = y * k + canvas.height / 2;

        ctx.beginPath();
        ctx.arc(px, py, k, 0, Math.PI * 2);
        ctx.fillStyle = 'white';
        ctx.fill();
      });

      requestAnimationFrame(animate);
    };

    window.addEventListener('resize', resize);
    resize();
    animate();

    return () => window.removeEventListener('resize', resize);
  }, []);

  return <canvas ref={canvasRef} style={{ display: 'block' }} />;
};

function App() {
  return (
    <div className="scene">
      <Starfield />
      <header className="scene-header">
        <h1>OMNIS CORE</h1>
        <button>ENTER THE FLOW</button>
      </header>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
